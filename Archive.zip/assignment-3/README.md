# Assignment 3:
How to use App of App Pattern

# Solution 
